import pymysql
import datetime

# 数据库配置
DB_HOST = 'localhost'
DB_USER = 'root'
DB_PASSWORD = 'root'
DB_NAME = 'exp4_db'

def get_db_connection():
    return pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASSWORD, database=DB_NAME, cursorclass=pymysql.cursors.DictCursor)

def register_user(username, password, role="user", is_banned="false"):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        if cursor.fetchone():
            raise ValueError("用户名已被注册")
        cursor.execute("INSERT INTO users (username, password, role, is_banned) VALUES (%s, %s, %s, %s)", (username, password, role, is_banned))
        conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        return {"error": str(e)}
    except ValueError as e:
        conn.rollback()
        return {"error": str(e)}
    finally:
        cursor.close()
        conn.close()
    return {"success": "用户注册成功"}

def login_user(username, password):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM users where username = %s and password = %s", (username, password))
        user = cursor.fetchone()
        return user
    except pymysql.Error as e:
        raise e
    finally:
        cursor.close()
        conn.close()

def show_all_products():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM special_products")
        products = cursor.fetchall()
        return products
    except pymysql.Error as e:
        return None
    finally:
        cursor.close()
        conn.close()

def show_my_products(current_user):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM my_products WHERE username = %s", (current_user,))
        products = cursor.fetchall()
        return products
    except pymysql.Error as e:
        return None
    finally:
        cursor.close()
        conn.close()

def make_order(product_name, quantity, current_user):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # 检测是否已存在该物品
        cursor.execute("SELECT quantity FROM my_products WHERE product_name = %s and username = %s", (product_name, current_user))
        result = cursor.fetchone()
        if result:
            # 如果存在，更新该物品
            new_quantity = result['quantity'] + int(quantity)
            cursor.execute("UPDATE my_products SET quantity = %s WHERE product_name = %s AND username = %s", (new_quantity, product_name, current_user))
            # 添加订单
            cursor.execute("INSERT INTO history_orders (username, product_name, quantity, make_order_time) VALUES (%s, %s, %s, %s)", (current_user, product_name, quantity, datetime.datetime.now()))
        else:
            # 否则插入
            cursor.execute("INSERT INTO my_products (product_name, quantity, username) VALUES (%s, %s, %s)", (product_name, quantity, current_user))
            cursor.execute("INSERT INTO history_orders (username, product_name, quantity, make_order_time) VALUES (%s, %s, %s, %s)",(current_user, product_name, quantity, datetime.datetime.now()))
            conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()

def add_carts(product_name, quantity, current_user):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # 检测购物车内是否存在该物品
        cursor.execute("SELECT quantity FROM my_carts WHERE product_name = %s AND username = %s", (product_name, current_user))
        result = cursor.fetchone()
        if result:
            # 如果存在，更新该物品
            new_quantity = result['quantity'] + int(quantity)
            cursor.execute("UPDATE my_carts SET quantity = %s WHERE product_name = %s AND username = %s", (new_quantity, product_name, current_user))
        else:
            # 否则插入
            cursor.execute("INSERT INTO my_carts (product_name, quantity, username) VALUES (%s, %s, %s)", (product_name, quantity, current_user))
            conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()

def show_carts(current_user):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM my_carts WHERE username = %s", (current_user))
        products = cursor.fetchall()
        return products
    except pymysql.Error as e:
        return None
    finally:
        cursor.close()
        conn.close()

# 清空购物车
def clear_carts(product_name, current_user):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM my_carts WHERE username = %s AND product_name = %s", (current_user, product_name))
        conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()

def add_favorites(product_name, current_user):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # 检测收藏夹内是否存在该物品
        cursor.execute("SELECT * FROM my_favorite WHERE username = %s AND product_name = %s", (current_user, product_name))
        result = cursor.fetchone()
        if result:
            # 如果存在，提示已存在
            raise ValueError("Your favorite collection has included this object.")
        else:
            # 否则插入
            cursor.execute("INSERT INTO my_favorite (product_name, username) VALUES (%s, %s)", (product_name,  current_user))
            conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
    except ValueError as e:
        conn.rollback()
        return {"error": str(e)}
    finally:
        cursor.close()
        conn.close()
    return {"success": "1"}

def show_my_favorite(current_user):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM my_favorite WHERE username = %s", (current_user))
        products = cursor.fetchall()
        return products
    except pymysql.Error as e:
        return None
    finally:
        cursor.close()
        conn.close()

def add_product(current_user, product_category, product_name, description, origin, price, sales_start_date, sales_end_date):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # 检测是否上传了完全一致的产品
        cursor.execute("SELECT * FROM special_products WHERE username = %s AND category = %s AND name = %s AND description = %s and origin = %s and price = %s and sales_start_date = %s and sales_end_date = %s", (current_user, product_category, product_name, description, origin, price, sales_start_date, sales_end_date))
        result = cursor.fetchone()
        if result:
            raise ValueError("This product has existed.")
        else:
            cursor.execute("INSERT INTO special_products (username, category, name, description, origin, price, sales_start_date, sales_end_date) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)", (current_user, product_category, product_name, description, origin, price, sales_start_date, sales_end_date))
            conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
    except ValueError as e:
        conn.rollback()
        return {"error": str(e)}
    finally:
        cursor.close()
        conn.close()
    return {"success": "1"}

def remove_my_favorite(current_user, product_name):
    # 写了一个存储过程的函数remove_favorite
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("CALL RemoveFavorite(%s, %s)", (product_name, current_user))
        conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()

def show_history_orders(current_user):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM history_orders WHERE username = %s", (current_user))
        products = cursor.fetchall()
        return products
    except pymysql.Error as e:
        return None
    finally:
        cursor.close()
        conn.close()


def get_complaints(current_user):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM my_complaint WHERE username = %s", (current_user))
        products = cursor.fetchall()
        return products
    except pymysql.Error as e:
        return None
    finally:
        cursor.close()
        conn.close()

def submit_complaints(current_user, product_name, make_order_time, complaint_reason):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # 检测是否上传了完全一致的投诉
        cursor.execute("SELECT * FROM my_complaint WHERE username = %s AND product_name = %s and make_order_time = %s and complaint_reason = %s", (current_user, product_name, make_order_time, complaint_reason))
        result = cursor.fetchone()
        if result:
            raise ValueError("This complaint has existed.")
        else:
            cursor.execute("INSERT INTO my_complaint (username, product_name, make_order_time, complaint_reason) VALUES (%s, %s, %s, %s)", (current_user, product_name, make_order_time, complaint_reason))
            conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
    except ValueError as e:
        conn.rollback()
        return {"error": str(e)}
    finally:
        cursor.close()
        conn.close()
    return {"success": "1"}

def show_all_users():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM users")
        products = cursor.fetchall()
        return products
    except pymysql.Error as e:
        return None
    finally:
        cursor.close()
        conn.close()

def set_ban(banned_username, ban_reason):
    conn = get_db_connection()
    cursor = conn.cursor()
    # 检测用户是否存在
    try:
        cursor.execute("SELECT * FROM users WHERE username = %s", (banned_username, ))
        result = cursor.fetchone()
        if not result:
            raise ValueError("no such user in db")
        else:
            cursor.execute("INSERT INTO banned_user (username, ban_reason) VALUES (%s, %s)", (banned_username, ban_reason))
            conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
    except ValueError as e:
        conn.rollback()
        return {"error": str(e)}
    finally:
        cursor.close()
        conn.close()
    return {"success": "1"}

def set_unban(banned_username):
    conn = get_db_connection()
    cursor = conn.cursor()
    # 检测用户是否存在
    try:
        cursor.execute("SELECT * FROM users WHERE username = %s", (banned_username, ))
        result = cursor.fetchone()
        if not result:
            raise ValueError("no such user in db")
        else:
            cursor.execute("DELETE FROM banned_user WHERE username = %s", (banned_username, ))
            conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
    except ValueError as e:
        conn.rollback()
        return {"error": str(e)}
    finally:
        cursor.close()
        conn.close()
    return {"success": "1"}

def show_all_complaint_admin():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM my_complaint")
        products = cursor.fetchall()
        return products
    except pymysql.Error as e:
        return None
    finally:
        cursor.close()
        conn.close()

def update_complaint(complaint_user, complaint_product_name, admin_response):
    conn = get_db_connection()
    cursor = conn.cursor()
    # 检测用户是否存在
    try:
        cursor.execute("SELECT * FROM my_complaint WHERE username = %s and product_name = %s", (complaint_user, complaint_product_name))
        result = cursor.fetchone()
        if not result:
            raise ValueError("no such record in db")
        else:
            cursor.execute("UPDATE my_complaint SET admin_response = %s WHERE username = %s AND product_name = %s", (admin_response, complaint_user, complaint_product_name))
            conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
    except ValueError as e:
        conn.rollback()
        return {"error": str(e)}
    finally:
        cursor.close()
        conn.close()
    return {"success": "1"}

def _withdraw(product_name, seller):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE from special_products WHERE name = %s and username = %s", (product_name, seller))
        conn.commit()
        cursor.execute("DELETE from my_favorite WHERE product_name = %s ", (product_name, ))
        conn.commit()
        cursor.execute("DELETE from my_carts WHERE product_name = %s ", (product_name,))
        conn.commit()
    except pymysql.Error as e:
        conn.rollback()
        raise e
        return {"error": str(e)}
    finally:
        cursor.close()
        conn.close()
    return {"success": "1"}