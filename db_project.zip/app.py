from flask import Flask
from flask_jwt_extended import JWTManager
import os
from controllers import auth_controller, user_controller, product_controller, purchase_controller, complaint_controller, admin_controller

app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = os.urandom(64)
app.config['JWT_COOKIE_CSRF_PROTECT'] = False
JWT_TOKEN_LOCATION = ["cookies"]
jwt = JWTManager(app)

app.register_blueprint(auth_controller.bp)
app.register_blueprint(user_controller.bp)
app.register_blueprint(product_controller.bp)
app.register_blueprint(purchase_controller.bp)
app.register_blueprint(complaint_controller.bp)
app.register_blueprint(admin_controller.bp)

if __name__ == '__main__':
    app.run()
