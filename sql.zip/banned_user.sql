INSERT INTO `banned_user` (`username`, `ban_reason`) VALUES ('banned_test_user', '123');
