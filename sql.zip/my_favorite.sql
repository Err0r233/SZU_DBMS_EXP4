INSERT INTO `my_favorite` (`product_name`, `username`) VALUES ('Eggs', '123');
INSERT INTO `my_favorite` (`product_name`, `username`) VALUES ('Mango', '123');
