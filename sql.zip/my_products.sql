INSERT INTO `my_products` (`product_name`, `quantity`, `username`) VALUES ('Apple', 17, '123');
INSERT INTO `my_products` (`product_name`, `quantity`, `username`) VALUES ('菠萝', 1, '123');
