INSERT INTO `my_carts` (`product_name`, `quantity`, `username`) VALUES ('Apple', 1, '123');
